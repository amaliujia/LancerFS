find . -name '*.cpp' | xargs wc -l 
