gdb build/bin/cloudfs
