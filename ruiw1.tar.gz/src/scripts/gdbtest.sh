./reset.sh
./mount_disks.sh
./run_server.sh 
