./snapshot /home/student/mnt/fuse/.snapshot r 1430422764 
