cp big4 /home/student/mnt/fuse/
./snapshot /home/student/mnt/fuse/.snapshot s
