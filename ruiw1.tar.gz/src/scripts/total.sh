./test_part1.sh small_test.tar.gz
./test_part1.sh	big_test.tar.gz
./test_part1.sh	large_test.tar.gz
./test_part2.sh small_test.tar.gz
./test_part2.sh	big_test.tar.gz
./test_part2.sh	large_test.tar.gz
./reset.sh
./test_part3.sh
./reset.sh 
./test_part3_2.sh large_test.tar.gz
./reset.sh
./test_part3_3.sh large_test.tar.gz
./reset.sh
