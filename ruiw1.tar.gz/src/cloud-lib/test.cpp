#include "libs3.h"
#include<iostream> 

using namespace std;
int main(){
	cout << "hello" << endl;	
}
