#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <fuse.h>
#include <getopt.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>
#include "cloudapi.h"
#include "cloudfs.h"
#include "cloud_handler.h"

int test() {
  printf("Start test!\n");

  cloud_init("localhost:8888");
  cloud_print_error();
  cloud_list_service(list_service);
  cloud_print_error();

  printf("Create bucket\n");
  cloud_create_bucket("test");
  cloud_print_error();

  cloud_list_service(list_service);
  cloud_print_error();

  cloud_put("test","./a.txt");
  printf("List bucket test\n");
  cloud_list_bucket("test", list_bucket);
  cloud_print_error();
/*
  printf("List bucket test:\n");
  cloud_list_bucket("test", list_bucket);

  printf("Get object:\n");
  outfile = fopen("/tmp/README", "wb");
  cloud_get_object("test", "helloworld", get_buffer);
  fclose(outfile);
  cloud_print_error();

  printf("Delete object:\n");
  cloud_delete_object("test", "helloworld");
  cloud_print_error();

  printf("List bucket test:\n");
  cloud_list_bucket("test", list_bucket);
  cloud_print_error();

  printf("Delete bucket test:\n");
  cloud_delete_bucket("test");
  cloud_print_error();
*/
  printf("List service:\n");
  cloud_list_service(list_service);
  cloud_get("test","./a.txt");
  printf("End test!\n");

  cloud_destroy();
  return 0;
}

int main() {
  return test();
}
