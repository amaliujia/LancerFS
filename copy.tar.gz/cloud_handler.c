#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <fuse.h>
#include <getopt.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>
#include "cloudapi.h"
//#include "cloudfs.h"
#include "cloud_handler.h"
#include <libgen.h>
#include "log.h"
void change_path(char *path)
{
	unsigned int i;
	for(i = 0; i < strlen(path)-1;i++)
	{
		if(path[i]=='/')
			path[i]='_';
	}
}
int list_bucket(const char *key, time_t modified_time, uint64_t size) {
  log_msg("LOG  LIST BUCKET %s %lu %llu\n", key, modified_time, size);
  return 0;
}

int list_service(const char *bucketName) {
  log_msg("LOG LIST SERVICE %s\n", bucketName);
  return 0;
}

static FILE *outfile;
int get_buffer(const char *buffer, int bufferLength) {
  return fwrite(buffer, 1, bufferLength, outfile);
}

static FILE *infile;
int put_buffer(char *buffer, int bufferLength) {
  log_msg("put_buffer %d \n", bufferLength);
  return fread(buffer, 1, bufferLength, infile);
}
/*put the real file into cloud and delete the file locally*/
int cloud_put(char *bucket, char *path)
{   
    log_msg("Put object%s\n",path);
    infile = fopen(path, "rb");
    if(infile == NULL)
    {
        log_msg("File not found.");
        abort();
    }
    log_msg("File open success");
    struct stat stat_buf;
    lstat(path, &stat_buf);
    /*put*/
    char *cloud_path = strdup(path);
    change_path(cloud_path);
    log_msg("after change, put %s\n",cloud_path);
    cloud_put_object(bucket, cloud_path, stat_buf.st_size, put_buffer);
    fclose(infile);
    cloud_print_error();
    free(cloud_path);
    return 0;
}
int cloud_get(char *bucket, char *path)
{
    char* cloud_path = strdup(path);
    log_msg("Get object:%s\n",path);
    outfile = fopen(path, "wb");
    change_path(cloud_path);
    cloud_get_object(bucket, cloud_path, get_buffer);
    fclose(outfile);
    cloud_print_error();
    free(cloud_path);
	return 0;
}

int cloud_delete_file(char *bucket, char *path)
{
	char *cloud_path = strdup(path);
	change_path(cloud_path);
	cloud_delete_object(bucket, cloud_path);
	free(cloud_path);
	return 0;	
}
