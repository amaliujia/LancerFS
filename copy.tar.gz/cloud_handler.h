int cloud_put(char *bucket,char *path);
int cloud_get(char *bucket, char *path);
int cloud_delete_file(char *bucket, char *path);
int list_bucket(const char *key, time_t modified_time, uint64_t size);
int list_service(const char *bucketName);
