#!/bin/bash
python ./s3server.pyc -p 8888 -v &
