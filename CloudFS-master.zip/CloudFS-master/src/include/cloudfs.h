#ifndef __CLOUDFS_H_
#define __CLOUDFS_H_

#define MAX_PATH_LEN 4096
#define MAX_HOSTNAME_LEN 1024
#include "dedup.h"
#include <openssl/md5.h>


struct file_info{
  char path[MAX_PATH_LEN];
  struct chunk *chunk_list;
  struct file_info *next;
};

struct chunk{
  size_t size;
  char md5[(MD5_DIGEST_LENGTH+1)*2];
  struct chunk *next;
};



struct cloudfs_state {
  char ssd_path[MAX_PATH_LEN];
  char fuse_path[MAX_PATH_LEN];
  char hostname[MAX_HOSTNAME_LEN];
  int ssd_size;
  int threshold;
  int avg_seg_size;
  int rabin_window_size;
  int cache_size;
  char no_dedup;
  char no_cache;
  char no_compress;
};



int cloudfs_start(struct cloudfs_state* state,
                  const char* fuse_runtime_name);  
void cloudfs_get_fullpath(const char *path, char *fullpath);
#endif
