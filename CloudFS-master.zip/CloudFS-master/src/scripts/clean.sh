
./cloudfs_controller.sh u
./umount_disks.sh
./format_disks.sh
./mount_disks.sh /mnt/ssd
